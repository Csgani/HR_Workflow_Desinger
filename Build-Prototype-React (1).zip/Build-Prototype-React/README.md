# HR Workflow Designer Prototype

This is a React-based prototype for an HR Workflow Designer, built as a technical assessment. It allows users to visually design, configure, and simulate HR processes.

## Architecture

### Tech Stack
- **Framework**: React (Vite)
- **State Management**: React Flow's internal state + React Local State
- **UI Components**: Shadcn/UI (Radix Primitives + Tailwind)
- **Diagramming**: @xyflow/react (React Flow)
- **Styling**: Tailwind CSS v4

### Folder Structure
- `client/src/components/workflow/`
  - `custom-nodes.tsx`: Defines the visual appearance of Start, Task, Approval, etc.
  - `sidebar.tsx`: The drag-and-drop source panel.
  - `node-forms.tsx`: The dynamic configuration panel that changes based on selected node.
- `client/src/lib/workflow/`
  - `types.ts`: TypeScript definitions for Node Data and Workflow structures.
  - `mock-api.ts`: Simulates backend interactions (fetching actions, running simulations).
- `client/src/pages/workflow-editor.tsx`: The main orchestration layer.

### Design Decisions
1.  **Separation of Concerns**: Node logic (visuals) is separated from Node Data (forms). The `NodePropertiesPanel` is a smart component that acts as a controller for the selected node's data.
2.  **Extensibility**: Adding a new node type requires:
    - Adding the type to `types.ts`
    - Creating a component in `custom-nodes.tsx`
    - Adding a form in `node-forms.tsx`
    - Registering it in `sidebar.tsx`
3.  **Mocking**: The API layer uses `setTimeout` to simulate async latency, ensuring the UI handles loading states correctly (e.g., during simulation).

## Features
- **Drag & Drop Canvas**: Drag nodes from the sidebar.
- **Dynamic Configuration**: Click a node to edit its specific properties (e.g., assignees, roles, automation actions).
- **Simulation Engine**: A client-side BFS traversal mimics server-side workflow execution, validating the path from Start to End.
- **Validation**: Basic checks for Start/End nodes.

## Running the Project
1.  `npm install`
2.  `npm run dev`
3.  Open http://localhost:5000

## Future Improvements
- **Persistent Storage**: Save workflows to a real backend.
- **Complex Validation**: Cycle detection (currently handled by step limit in simulation) and unreachable node warnings.
- **Version History**: Undo/Redo support using `zundo` or similar middleware.
