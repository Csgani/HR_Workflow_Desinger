import React, { useEffect, useState } from 'react';
import { useReactFlow } from '@xyflow/react';
import { Node } from '@xyflow/react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { X } from 'lucide-react';
import { fetchAutomatedActions } from '@/lib/workflow/mock-api';

interface NodeFormsProps {
  selectedNode: Node | null;
  onClose: () => void;
}

export function NodePropertiesPanel({ selectedNode, onClose }: NodeFormsProps) {
  const { setNodes } = useReactFlow();
  
  if (!selectedNode) return null;

  const updateNodeData = (key: string, value: any) => {
    setNodes((nodes) =>
      nodes.map((node) => {
        if (node.id === selectedNode.id) {
          return {
            ...node,
            data: {
              ...node.data,
              [key]: value,
            },
          };
        }
        return node;
      })
    );
  };

  return (
    <aside className="w-80 border-l border-border bg-card h-full flex flex-col shadow-xl absolute right-0 top-0 z-10">
      <div className="p-4 border-b border-border flex items-center justify-between bg-muted/30">
        <div>
          <h2 className="font-semibold text-lg">Properties</h2>
          <p className="text-xs text-muted-foreground font-mono">{selectedNode.type} Node</p>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8">
          <X size={16} />
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {/* Common Fields */}
        <div className="space-y-2">
          <Label htmlFor="label">Label</Label>
          <Input 
            id="label"
            value={selectedNode.data.label as string || ''}
            onChange={(e) => updateNodeData('label', e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Description</Label>
          <Textarea 
            id="description"
            className="resize-none h-20"
            value={selectedNode.data.description as string || ''}
            onChange={(e) => updateNodeData('description', e.target.value)}
          />
        </div>

        <Separator />

        {/* Node Specific Fields */}
        {selectedNode.type === 'start' && <StartNodeForm data={selectedNode.data} updateData={updateNodeData} />}
        {selectedNode.type === 'task' && <TaskNodeForm data={selectedNode.data} updateData={updateNodeData} />}
        {selectedNode.type === 'approval' && <ApprovalNodeForm data={selectedNode.data} updateData={updateNodeData} />}
        {selectedNode.type === 'automated' && <AutomatedNodeForm data={selectedNode.data} updateData={updateNodeData} />}
        {selectedNode.type === 'end' && <EndNodeForm data={selectedNode.data} updateData={updateNodeData} />}
      </div>
    </aside>
  );
}

// --- Specific Forms ---

const StartNodeForm = ({ data, updateData }: any) => {
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Metadata (JSON)</Label>
        <Textarea 
          placeholder='{"source": "HR Portal"}'
          className="font-mono text-xs"
          value={typeof data.metadata === 'object' ? JSON.stringify(data.metadata) : data.metadata || ''}
          onChange={(e) => {
            try {
              const parsed = JSON.parse(e.target.value);
              updateData('metadata', parsed);
            } catch (err) {
              // Allow typing invalid json, maybe handle validation later
              updateData('metadata', e.target.value); 
            }
          }}
        />
        <p className="text-[10px] text-muted-foreground">Enter valid JSON for metadata.</p>
      </div>
    </div>
  );
};

const TaskNodeForm = ({ data, updateData }: any) => {
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Assignee</Label>
        <Input 
          value={data.assignee || ''} 
          onChange={(e) => updateData('assignee', e.target.value)} 
          placeholder="e.g. employee@company.com"
        />
      </div>
      <div className="space-y-2">
        <Label>Due Date</Label>
        <Input 
          type="date"
          value={data.dueDate || ''} 
          onChange={(e) => updateData('dueDate', e.target.value)} 
        />
      </div>
    </div>
  );
};

const ApprovalNodeForm = ({ data, updateData }: any) => {
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Approver Role</Label>
        <Select 
          value={data.approverRole || ''} 
          onValueChange={(val) => updateData('approverRole', val)}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select role" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="manager">Manager</SelectItem>
            <SelectItem value="hr_bp">HR Business Partner</SelectItem>
            <SelectItem value="director">Director</SelectItem>
            <SelectItem value="vp">VP</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <Label>Auto-Approve Threshold ($)</Label>
        <Input 
          type="number"
          value={data.autoApproveThreshold || ''} 
          onChange={(e) => updateData('autoApproveThreshold', parseFloat(e.target.value))} 
        />
      </div>
    </div>
  );
};

const AutomatedNodeForm = ({ data, updateData }: any) => {
  const [actions, setActions] = useState<any[]>([]);

  useEffect(() => {
    fetchAutomatedActions().then(setActions);
  }, []);

  const selectedAction = actions.find(a => a.id === data.actionId);

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Action</Label>
        <Select 
          value={data.actionId || ''} 
          onValueChange={(val) => {
            updateData('actionId', val);
            updateData('actionParams', {}); // Reset params on change
          }}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select system action" />
          </SelectTrigger>
          <SelectContent>
            {actions.map(action => (
              <SelectItem key={action.id} value={action.id}>{action.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {selectedAction && (
        <div className="space-y-3 p-3 bg-muted/50 rounded-md border border-border">
          <Label className="text-xs font-semibold uppercase text-muted-foreground">Parameters</Label>
          {selectedAction.params.map((param: any) => (
            <div key={param.name} className="space-y-1">
              <Label className="text-xs">{param.label}</Label>
              {param.type === 'select' ? (
                <Select 
                  value={data.actionParams?.[param.name] || ''}
                  onValueChange={(val) => updateData('actionParams', { ...data.actionParams, [param.name]: val })}
                >
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {param.options.map((opt: string) => (
                      <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : param.type === 'textarea' ? (
                 <Textarea 
                    className="h-16 text-xs"
                    value={data.actionParams?.[param.name] || ''}
                    onChange={(e) => updateData('actionParams', { ...data.actionParams, [param.name]: e.target.value })}
                 />
              ) : (
                <Input 
                  className="h-8 text-xs"
                  value={data.actionParams?.[param.name] || ''}
                  onChange={(e) => updateData('actionParams', { ...data.actionParams, [param.name]: e.target.value })}
                />
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

const EndNodeForm = ({ data, updateData }: any) => {
  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>End Message</Label>
        <Textarea 
          value={data.endMessage || ''} 
          onChange={(e) => updateData('endMessage', e.target.value)} 
          placeholder="Workflow completed successfully."
        />
      </div>
      <div className="flex items-center justify-between">
        <Label>Show Summary</Label>
        <Switch 
          checked={data.isSummary || false}
          onCheckedChange={(checked) => updateData('isSummary', checked)}
        />
      </div>
    </div>
  );
};
