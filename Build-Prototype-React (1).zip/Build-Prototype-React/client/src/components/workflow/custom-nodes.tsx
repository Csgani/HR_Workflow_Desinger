import React, { memo } from 'react';
import { Handle, Position, NodeProps } from '@xyflow/react';
import { Play, CheckSquare, FileText, Zap, Flag } from 'lucide-react';
import { cn } from '@/lib/utils';

// Helper for common node styling
const BaseNode = ({ 
  children, 
  selected, 
  icon: Icon, 
  colorClass, 
  label,
  isStart = false,
  isEnd = false
}: any) => {
  return (
    <div className={cn(
      "relative px-4 py-3 shadow-md rounded-lg bg-card border-2 w-[200px] transition-all",
      selected ? "border-primary ring-2 ring-primary/20" : "border-border",
      "hover:shadow-lg"
    )}>
      {!isStart && (
        <Handle 
          type="target" 
          position={Position.Top} 
          className="!w-4 !h-4 !bg-muted-foreground !border-2 !border-background -mt-2 transition-transform hover:scale-125 hover:bg-primary" 
        />
      )}
      
      <div className="flex items-center gap-3">
        <div className={cn("p-2 rounded-md text-white shadow-sm", colorClass)}>
          <Icon size={16} />
        </div>
        <div>
          <h3 className="text-sm font-semibold text-foreground leading-tight">{label}</h3>
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium mt-0.5">
            {children}
          </p>
        </div>
      </div>

      {!isEnd && (
        <Handle 
          type="source" 
          position={Position.Bottom} 
          className="!w-4 !h-4 !bg-muted-foreground !border-2 !border-background -mb-2 transition-transform hover:scale-125 hover:bg-primary" 
        />
      )}
    </div>
  );
};

export const StartNode = memo(({ data, selected }: NodeProps) => {
  return (
    <BaseNode 
      selected={selected} 
      icon={Play} 
      colorClass="bg-blue-500" 
      label={data.label || "Start"} 
      isStart
    >
      Entry Point
    </BaseNode>
  );
});

export const TaskNode = memo(({ data, selected }: NodeProps) => {
  return (
    <BaseNode 
      selected={selected} 
      icon={CheckSquare} 
      colorClass="bg-emerald-500" 
      label={data.label || "Task"}
    >
      Human Task
    </BaseNode>
  );
});

export const ApprovalNode = memo(({ data, selected }: NodeProps) => {
  return (
    <BaseNode 
      selected={selected} 
      icon={FileText} 
      colorClass="bg-amber-500" 
      label={data.label || "Approval"}
    >
      Review
    </BaseNode>
  );
});

export const AutomatedNode = memo(({ data, selected }: NodeProps) => {
  return (
    <BaseNode 
      selected={selected} 
      icon={Zap} 
      colorClass="bg-purple-500" 
      label={data.label || "Automation"}
    >
      System Action
    </BaseNode>
  );
});

export const EndNode = memo(({ data, selected }: NodeProps) => {
  return (
    <BaseNode 
      selected={selected} 
      icon={Flag} 
      colorClass="bg-slate-500" 
      label={data.label || "End"} 
      isEnd
    >
      Completion
    </BaseNode>
  );
});

export const nodeTypes = {
  start: StartNode,
  task: TaskNode,
  approval: ApprovalNode,
  automated: AutomatedNode,
  end: EndNode,
};
