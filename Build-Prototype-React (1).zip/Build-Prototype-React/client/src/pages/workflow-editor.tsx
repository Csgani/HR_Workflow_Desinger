import React, { useState, useCallback, useRef } from 'react';
import { 
  ReactFlow, 
  Controls, 
  Background, 
  useNodesState, 
  useEdgesState, 
  addEdge, 
  Connection, 
  Edge,
  ReactFlowProvider,
  Node,
  MarkerType,
  useReactFlow
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';

import { Sidebar } from '@/components/workflow/sidebar';
import { nodeTypes } from '@/components/workflow/custom-nodes';
import { NodePropertiesPanel } from '@/components/workflow/node-forms';
import { Button } from '@/components/ui/button';
import { Play, Save, Trash2, ArrowRight, Download } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { simulateWorkflow } from '@/lib/workflow/mock-api';
import { WorkflowDefinition, WorkflowNode } from '@/lib/workflow/types';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const initialNodes: Node[] = [
  { 
    id: '1', 
    type: 'start', 
    position: { x: 50, y: 50 }, 
    data: { label: 'New Hire' } 
  },
  { 
    id: '2', 
    type: 'task', 
    position: { x: 300, y: 50 }, 
    data: { label: 'Collect Documents', assignee: 'HR Admin' } 
  },
  { 
    id: '3', 
    type: 'approval', 
    position: { x: 550, y: 50 }, 
    data: { label: 'Manager Approval', approverRole: 'manager' } 
  },
  { 
    id: '4', 
    type: 'end', 
    position: { x: 800, y: 50 }, 
    data: { label: 'Onboarding Complete', isSummary: true } 
  },
];

const initialEdges: Edge[] = [
  { id: 'e1-2', source: '1', target: '2', animated: true },
  { id: 'e2-3', source: '2', target: '3', animated: true },
  { id: 'e3-4', source: '3', target: '4', animated: true },
];

const defaultEdgeOptions = {
  type: 'smoothstep',
  markerEnd: {
    type: MarkerType.ArrowClosed,
    width: 20,
    height: 20,
    color: '#64748b',
  },
  style: {
    strokeWidth: 2,
    stroke: '#64748b',
  },
  animated: true,
};

function WorkflowEditorContent() {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  
  // Simulation State
  const [isSimulating, setIsSimulating] = useState(false);
  const [simulationSteps, setSimulationSteps] = useState<any[]>([]);
  const [showSimulation, setShowSimulation] = useState(false);

  const reactFlowWrapper = useRef<HTMLDivElement>(null);
  const [reactFlowInstance, setReactFlowInstance] = useState<any>(null);
  
  const { getNodes, getEdges } = useReactFlow();

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges],
  );

  const onDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }, []);

  const onDrop = useCallback(
    (event: React.DragEvent) => {
      event.preventDefault();

      const type = event.dataTransfer.getData('application/reactflow');
      if (typeof type === 'undefined' || !type) {
        return;
      }

      const position = reactFlowInstance.screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      });

      const newNode: Node = {
        id: crypto.randomUUID(),
        type,
        position,
        data: { label: `New ${type.charAt(0).toUpperCase() + type.slice(1)}` },
      };

      setNodes((nds) => nds.concat(newNode));
    },
    [reactFlowInstance, setNodes],
  );

  const onNodeClick = useCallback((_: React.MouseEvent, node: Node) => {
    setSelectedNode(node);
  }, []);

  const onPaneClick = useCallback(() => {
    setSelectedNode(null);
  }, []);

  const handleSimulate = async () => {
    // Cast nodes to WorkflowNode[] as we know our types match at runtime
    const workflow: WorkflowDefinition = { 
      nodes: nodes as WorkflowNode[], 
      edges 
    };
    
    // Basic Validation
    const hasStart = nodes.some(n => n.type === 'start');
    const hasEnd = nodes.some(n => n.type === 'end');
    
    if (!hasStart) {
      toast({ title: "Validation Error", description: "Workflow must have a Start Node.", variant: "destructive" });
      return;
    }
    if (!hasEnd) {
      toast({ title: "Validation Warning", description: "Workflow usually ends with an End Node.", variant: "default" });
    }

    setIsSimulating(true);
    setShowSimulation(true);
    setSimulationSteps([]);

    try {
      const steps = await simulateWorkflow(workflow);
      setSimulationSteps(steps);
    } catch (error) {
      toast({ title: "Simulation Failed", description: "An unexpected error occurred.", variant: "destructive" });
    } finally {
      setIsSimulating(false);
    }
  };

  const handleExport = () => {
    const workflowData = {
      nodes: getNodes(),
      edges: getEdges(),
      exportedAt: new Date().toISOString(),
    };

    const blob = new Blob([JSON.stringify(workflowData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `workflow-export-${Date.now()}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({ title: "Exported", description: "Workflow downloaded as JSON." });
  };

  return (
    <div className="flex flex-col h-screen bg-background text-foreground overflow-hidden">
      {/* Header */}
      <header className="h-14 border-b border-border flex items-center justify-between px-6 bg-card">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center text-primary-foreground font-bold">
            W
          </div>
          <h1 className="font-semibold text-lg">Workflow Designer</h1>
        </div>
        <div className="flex items-center gap-2">
           <Button variant="outline" size="sm" onClick={handleExport}>
            <Download className="w-4 h-4 mr-2" />
            Export JSON
          </Button>
          <Button size="sm" onClick={handleSimulate} disabled={isSimulating}>
            <Play className="w-4 h-4 mr-2" />
            Simulate
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        <Sidebar />
        
        <div className="flex-1 relative" ref={reactFlowWrapper}>
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            onInit={setReactFlowInstance}
            onDrop={onDrop}
            onDragOver={onDragOver}
            onNodeClick={onNodeClick}
            onPaneClick={onPaneClick}
            nodeTypes={nodeTypes}
            defaultEdgeOptions={defaultEdgeOptions}
            fitView
            className="bg-muted/10"
          >
            <Controls />
            <Background color="#94a3b8" gap={20} size={1} />
          </ReactFlow>

          {selectedNode && (
            <NodePropertiesPanel 
              selectedNode={selectedNode} 
              onClose={() => setSelectedNode(null)} 
            />
          )}
        </div>
      </div>

      {/* Simulation Dialog */}
      <Dialog open={showSimulation} onOpenChange={setShowSimulation}>
        <DialogContent className="max-w-2xl max-h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle>Workflow Simulation</DialogTitle>
            <DialogDescription>
              Step-by-step execution log of your designed workflow.
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex-1 overflow-y-auto mt-4 space-y-4 pr-2">
             {isSimulating && simulationSteps.length === 0 && (
               <div className="flex items-center justify-center py-8 text-muted-foreground">
                 Running simulation...
               </div>
             )}
             
             {simulationSteps.map((step, index) => (
               <div 
                  key={step.id} 
                  className={`flex items-start gap-4 p-4 rounded-lg border ${
                    step.status === 'failed' ? 'border-destructive/50 bg-destructive/10' : 
                    step.status === 'completed' ? 'border-green-500/20 bg-green-500/5' : 
                    'border-border bg-card'
                  }`}
               >
                 <div className="flex flex-col items-center gap-1">
                   <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                     step.status === 'failed' ? 'bg-destructive text-destructive-foreground' : 
                     'bg-primary text-primary-foreground'
                   }`}>
                     {index + 1}
                   </div>
                   {index < simulationSteps.length - 1 && <div className="w-0.5 h-full bg-border min-h-[20px]" />}
                 </div>
                 
                 <div className="flex-1">
                   <div className="flex items-center justify-between mb-1">
                     <span className="font-semibold text-sm">{step.nodeId}</span>
                     <span className="text-xs text-muted-foreground">{new Date(step.timestamp).toLocaleTimeString()}</span>
                   </div>
                   <p className="text-sm">{step.message}</p>
                 </div>
               </div>
             ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function WorkflowEditor() {
  return (
    <ReactFlowProvider>
      <WorkflowEditorContent />
    </ReactFlowProvider>
  );
}
