import { SimulationStep, WorkflowDefinition } from './types';

export const MOCK_ACTIONS = [
  { 
    id: 'send_email', 
    label: 'Send Email', 
    params: [
      { name: 'to', type: 'email', label: 'To' },
      { name: 'subject', type: 'text', label: 'Subject' },
      { name: 'body', type: 'textarea', label: 'Body' }
    ] 
  },
  { 
    id: 'generate_doc', 
    label: 'Generate Document', 
    params: [
      { name: 'template', type: 'select', options: ['Offer Letter', 'NDA', 'Contract'], label: 'Template' },
      { name: 'recipient', type: 'text', label: 'Recipient Name' }
    ] 
  },
  { 
    id: 'slack_notify', 
    label: 'Slack Notification', 
    params: [
      { name: 'channel', type: 'text', label: 'Channel ID' },
      { name: 'message', type: 'textarea', label: 'Message' }
    ] 
  },
  { 
    id: 'create_jira', 
    label: 'Create Jira Ticket', 
    params: [
      { name: 'project', type: 'text', label: 'Project Key' },
      { name: 'summary', type: 'text', label: 'Summary' }
    ] 
  }
];

export async function fetchAutomatedActions() {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  return MOCK_ACTIONS;
}

export async function simulateWorkflow(workflow: WorkflowDefinition): Promise<SimulationStep[]> {
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const steps: SimulationStep[] = [];
  const visited = new Set<string>();
  
  // Simple BFS/execution simulation
  // Find start node
  const startNode = workflow.nodes.find(n => n.type === 'start');
  if (!startNode) {
    return [{
      id: 'error',
      nodeId: 'none',
      status: 'failed',
      message: 'No Start Node found in workflow.',
      timestamp: new Date().toISOString()
    }];
  }

  let currentNode = startNode;
  
  // Limit steps to prevent infinite loops in bad graphs
  let stepCount = 0;
  const MAX_STEPS = 20;

  while (currentNode && stepCount < MAX_STEPS) {
    steps.push({
      id: `step-${stepCount}`,
      nodeId: currentNode.id,
      status: 'completed',
      message: `Executed ${currentNode.data.label} (${currentNode.type})`,
      timestamp: new Date().toISOString()
    });

    visited.add(currentNode.id);

    // Find outgoing edge
    const outEdges = workflow.edges.filter(e => e.source === currentNode?.id);
    
    if (outEdges.length === 0) {
       // No outgoing edges
       break;
    }

    // For this simple prototype, we just take the first path
    // In a real app, we might evaluate conditions here
    const outEdge = outEdges[0];

    const nextNode = workflow.nodes.find(n => n.id === outEdge.target);
    if (!nextNode) {
        steps.push({
          id: `step-error-${stepCount}`,
          nodeId: outEdge.target,
          status: 'failed',
          message: 'Target node not found in workflow definition.',
          timestamp: new Date().toISOString()
        });
        break;
    }
    currentNode = nextNode;
    stepCount++;
  }

  if (stepCount >= MAX_STEPS) {
    steps.push({
        id: `step-limit`,
        nodeId: currentNode?.id || 'unknown',
        status: 'failed',
        message: 'Simulation step limit reached (possible cycle).',
        timestamp: new Date().toISOString()
    });
  } else if (currentNode?.type !== 'end') {
      steps.push({
          id: `step-incomplete`,
          nodeId: currentNode?.id || 'unknown',
          status: 'failed',
          message: 'Workflow ended without reaching an End Node.',
          timestamp: new Date().toISOString()
      });
  } else {
       steps.push({
          id: `step-complete`,
          nodeId: currentNode.id,
          status: 'completed',
          message: 'Workflow completed successfully.',
          timestamp: new Date().toISOString()
      });
  }

  return steps;
}
