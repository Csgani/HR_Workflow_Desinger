import React from 'react';
import { cn } from '@/lib/utils';
import { Play, CheckSquare, FileText, Zap, Flag, GripVertical } from 'lucide-react';

export function Sidebar() {
  const onDragStart = (event: React.DragEvent, nodeType: string) => {
    event.dataTransfer.setData('application/reactflow', nodeType);
    event.dataTransfer.effectAllowed = 'move';
  };

  return (
    <aside className="w-64 border-r border-border bg-sidebar text-sidebar-foreground flex flex-col h-full">
      <div className="p-4 border-b border-sidebar-border">
        <h2 className="font-semibold text-lg tracking-tight">Toolkit</h2>
        <p className="text-sm text-muted-foreground">Drag nodes to canvas</p>
      </div>
      
      <div className="p-4 flex flex-col gap-3">
        <SidebarItem 
          type="start" 
          label="Start Node" 
          icon={Play} 
          color="text-blue-500" 
          onDragStart={onDragStart} 
        />
        <SidebarItem 
          type="task" 
          label="Task" 
          icon={CheckSquare} 
          color="text-emerald-500" 
          onDragStart={onDragStart} 
        />
        <SidebarItem 
          type="approval" 
          label="Approval" 
          icon={FileText} 
          color="text-amber-500" 
          onDragStart={onDragStart} 
        />
        <SidebarItem 
          type="automated" 
          label="Automation" 
          icon={Zap} 
          color="text-purple-500" 
          onDragStart={onDragStart} 
        />
        <SidebarItem 
          type="end" 
          label="End Node" 
          icon={Flag} 
          color="text-slate-500" 
          onDragStart={onDragStart} 
        />
      </div>

      <div className="mt-auto p-4 border-t border-sidebar-border bg-sidebar-accent/50">
        <div className="text-xs text-muted-foreground">
          <p><strong>Tip:</strong> Connect nodes to define the process flow.</p>
        </div>
      </div>
    </aside>
  );
}

const SidebarItem = ({ type, label, icon: Icon, color, onDragStart }: any) => {
  return (
    <div
      className="flex items-center gap-3 p-3 rounded-md border border-sidebar-border bg-card cursor-grab hover:border-primary hover:shadow-sm transition-all active:cursor-grabbing"
      onDragStart={(event) => onDragStart(event, type)}
      draggable
    >
      <GripVertical className="text-muted-foreground/50" size={16} />
      <div className={cn("p-1.5 rounded bg-muted", color)}>
        <Icon size={16} />
      </div>
      <span className="text-sm font-medium">{label}</span>
    </div>
  );
};
