
# HR Workflow Designer (React + React Flow)

## Features
- Custom nodes (Start, Task, Approval, Automated, End)
- Sidebar drag & drop
- Canvas editing
- Mock API integration
- Workflow JSON export-ready structure

## How to Run
```
npm install
npm run dev
```
