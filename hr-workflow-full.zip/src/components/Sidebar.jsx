
import React from "react";

export default function Sidebar() {
  const items = [
    { type: "start", label: "Start Node" },
    { type: "task", label: "Task Node" },
    { type: "approval", label: "Approval Node" },
    { type: "auto", label: "Automated Step" },
    { type: "end", label: "End Node" }
  ];

  return (
    <div className="sidebar">
      <h3>Nodes</h3>
      {items.map((item) => (
        <div key={item.type} className="node-box" draggable
          onDragStart={(e) => e.dataTransfer.setData("nodeType", item.type)}>
          {item.label}
        </div>
      ))}
    </div>
  );
}
