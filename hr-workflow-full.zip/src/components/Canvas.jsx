
import React, { useState, useCallback } from "react";
import ReactFlow, { addEdge, Background, Controls } from "react-flow-renderer";

export default function Canvas() {
  const [nodes, setNodes] = useState([]);
  const [edges, setEdges] = useState([]);

  const onConnect = useCallback(
    (params) => setEdges((eds) => addEdge(params, eds)),
    []
  );

  const onDrop = (e) => {
    const type = e.dataTransfer.getData("nodeType");
    if (!type) return;

    const position = { x: 200, y: 100 + nodes.length * 80 };
    setNodes((nds) => [
      ...nds,
      {
        id: `${Date.now()}`,
        type: "default",
        position,
        data: { label: `${type.toUpperCase()} NODE` }
      }
    ]);
  };

  return (
    <div className="canvas-container"
      onDrop={onDrop}
      onDragOver={(e) => e.preventDefault()}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={setNodes}
        onEdgesChange={setEdges}
        onConnect={onConnect}
      >
        <Background />
        <Controls />
      </ReactFlow>
    </div>
  );
}
