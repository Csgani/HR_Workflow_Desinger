
import React from 'react';
import Canvas from './components/Canvas.jsx';
import Sidebar from './components/Sidebar.jsx';
import './styles.css';

export default function App() {
  return (
    <div className="layout">
      <Sidebar />
      <Canvas />
    </div>
  );
}
